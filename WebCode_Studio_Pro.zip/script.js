const editor = document.getElementById('editor');
const preview = document.getElementById('preview');

function updatePreview() {
  const code = editor.innerText;
  preview.srcdoc = code;
}

editor.addEventListener('input', updatePreview);
window.addEventListener('load', updatePreview);

document.getElementById('newFileBtn').onclick = () => {
  editor.innerText = '<!DOCTYPE html>\n<html>\n<head>\n<title>New Page</title>\n</head>\n<body>\n<h1>Hello!</h1>\n</body>\n</html>';
  updatePreview();
};

document.getElementById('saveFileBtn').onclick = () => {
  const blob = new Blob([editor.innerText], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'index.html';
  a.click();
};

document.getElementById('downloadZipBtn').onclick = () => {
  alert('Download .ZIP feature will be integrated in GitHub version');
};